export function formatLifeRange(birthDate, deathDate) {
  console.log('deathDate', deathDate.length)
  console.log('birthDate', birthDate.length)
  const lines = [];

    if (deathDate.length > 0) {
    lines.push(`Deceased: ${deathDate}`);
  }

  if (birthDate.length > 0) {
    lines.push(`Birthdate: ${birthDate}`);
  } else {
    lines.push(`Birthdate: Unknown`);
  }

  // push line brake into index 1
  lines.splice(1, 0, '<br />');
  console.log('lines', lines);

  return lines

}