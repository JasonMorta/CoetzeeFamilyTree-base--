export function formatLifeRange(birthDate, deathDate) {
  console.log('deathDate', deathDate)
  console.log('birthDate', birthDate)
  const lines = [];

  if (birthDate) {
    lines.push(`Birthdate: ${birthDate}`);
  } else {
    lines.push(`Birthdate: Unknown`);
  }

  if (deathDate) {
    lines.push(`Deceased: ${deathDate}`);
  }

  return lines.join('\n');
}