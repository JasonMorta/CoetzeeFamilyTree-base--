export function formatLifeRange(birthDate, deathDate) {
  const lines = [];

  if (birthDate) {
    lines.push(`Birthdate: ${birthDate}`);
  }

  if (deathDate) {
    lines.push(`Deceased: ${deathDate}`);
  }

  return lines.join('\n');
}