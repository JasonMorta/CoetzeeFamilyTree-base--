export function formatLifeRange(birthDate, deathDate) {
  console.log('deathDate', deathDate.length)
  console.log('birthDate', birthDate.length)
  const lines = [];

    if (deathDate > 0) {
    lines.push(`Deceased: ${deathDate}\n `);
  }

  if (birthDate > 0) {
    lines.push(`Birthdate: ${birthDate}`);
  } else {
    lines.push(`Birthdate: Unknown`);
  }



  return lines;
}