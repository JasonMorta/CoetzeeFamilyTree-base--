export function formatLifeRange(birthDate, deathDate) {
  const birth = birthDate || '🪦 ';
  const death = deathDate || '';
  return `${birth} - ${death}`;
}
