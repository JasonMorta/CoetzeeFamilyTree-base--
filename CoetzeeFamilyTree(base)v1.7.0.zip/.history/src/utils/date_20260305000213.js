export function formatLifeRange(birthDate, deathDate) {
  const lines = '';

  if (birthDate) {
    lines += `Birthdate: ${birthDate}`;
  } else {
    lines += `Birthdate: Unknown`;
  }

  if (deathDate) {
    lines += `Deceased: ${deathDate}`;
  } else {
    lines += `Deceased: Unknown`;
  }

  return lines
}