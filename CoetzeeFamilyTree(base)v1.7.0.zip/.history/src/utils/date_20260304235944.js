export function formatLifeRange(birthDate, deathDate) {
  const lines = [];

  if (birthDate) {
    lines.push(`Birthdate: ${birthDate}`);
  } else if (!deathDate) {
    lines.push(`Birthdate: Unknown`);
  }

  if (deathDate) {
    lines.push(`Deceased: ${deathDate}`);
  }

  return lines.join('\n');
}