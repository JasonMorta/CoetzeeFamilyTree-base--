export function formatLifeRange(birthDate, deathDate) {
  console.log('deathDate', deathDate.length)
  console.log('birthDate', birthDate.length)
  const lines = [];

    if (deathDate.length > 0) {
    lines.push(`Deceased: ${deathDate}`);
  }

  if (birthDate.length > 0) {
    lines.push(`Birthdate: ${birthDate}`);
  } else {
    lines.push(`Birthdate: Unknown`);
  }

  console.log('lines', lines)

  return lines

}