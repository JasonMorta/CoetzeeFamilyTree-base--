export function formatLifeRange(birthDate, deathDate) {
  const birth = birthDate || '__';
  const death = deathDate || 'Present';
  return `${birth} - ${death}`;
}
