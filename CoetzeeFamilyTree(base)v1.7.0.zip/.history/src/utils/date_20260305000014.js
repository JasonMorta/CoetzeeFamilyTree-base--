export function formatLifeRange(birthDate, deathDate) {
  const lines = [];

  if (birthDate) {
    lines.push(`Birthdate: ${birthDate}`);
  } else {
    lines.push(`Birthdate: Unknown`);
  }

  if (deathDate) {
    lines.push(`Deceased: ${deathDate}`);
  }

  return lines.join('\n');
}